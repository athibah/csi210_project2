package Project02;

public class LinkedStringOutofBoundsException extends Exception {
public LinkedStringOutofBoundsException(String msg) {super(msg);}

}
