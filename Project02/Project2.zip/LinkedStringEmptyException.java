package Project02;

public class LinkedStringEmptyException extends Exception {

	public LinkedStringEmptyException(String msg) {
		super(msg);
	}
}
