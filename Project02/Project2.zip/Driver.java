package Project02;

import java.io.FileNotFoundException;

public class Driver {
	
	public static void main(String [] args ) throws FileNotFoundException, LinkedStringEmptyException {
		
		
		Helper.start();
	}

}
